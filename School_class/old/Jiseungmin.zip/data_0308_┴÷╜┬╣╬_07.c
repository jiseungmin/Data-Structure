/*
제목 : C언어 기본 자료형 실습 과제
작성자 : 컴퓨터공학부 지승민 
학번 : 2022243094
작성일자 : 3월 8일
*/

#include <stdio.h>

int main(){
    char ch1 = 'A';
    char ch2 = 65;

    char univ[10] = "SunMoon";

    printf("ch1=%c, %d\n", ch1, ch2);
    printf("ch2=%c, %d\n", ch2,ch1);

    printf("University:%s\n",univ);
    printf("University:%s %s\n", univ, "DGIST");
    
    return 0;
}