/*
제목 : C언어 기본 자료형 실습 과제
작성자 : 컴퓨터공학부 지승민 
학번 : 2022243094
작성일자 : 3월 8일
*/

#include <stdio.h>

int main(void){
    short a = 32767;
    int b = 2147483647;
    long c = 2147483647;
    long long d = 123451234512345;
    unsigned int e = 4294967295;
    unsigned int f = -3 ;

    printf("a=%d \t\t size=%d\n",a ,sizeof(a));
    printf("b=%d \t\t size=%d\n",b,sizeof(b));
    printf("c=%ld \t\t size=%d\n",c,sizeof(c));
    printf("d=%lld \t size=%d\n",d,sizeof(d));
    printf("e=%d %u \t size=%u\n",e,e,sizeof(e));
    printf("f=%d %u \t size=%u\n",f,f,sizeof(f));

    return 0;
}