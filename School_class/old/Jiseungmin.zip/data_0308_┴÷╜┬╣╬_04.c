/*
제목 : C언어 기본 자료형 실습 과제
작성자 : 컴퓨터공학부 지승민 
학번 : 2022243094
작성일자 : 3월 8일
*/

#include <stdio.h>

int main(void){
    int a ;
    int b,c ;
    double da ;
    char ch ;

    a = 10;
    b = a;
    c = a +20;
    da = 3.5;
    ch = 'A';

    printf("a=%d\n",a);
    printf("b=%d c=%d\n",b,c);
    printf("c=%d\n",c);
    printf("d=.1lf%d\n", da);
    printf("ch=%d\n",ch);

    return 0 ;
}