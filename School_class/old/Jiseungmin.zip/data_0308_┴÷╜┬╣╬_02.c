/*
제목 : C언어 기본 자료형 실습 과제
작성자 : 컴퓨터공학부 지승민 
학번 : 2022243094
작성일자 : 3월 8일
*/
#include <stdio.h>

int main(void){
    printf("%d\n",12);
    printf("%d\n",014);
    printf("%d\n",0xc);

    printf("%.1lf\n",1e6);
    printf("%.7lf\n", 3.14e-5);
    printf("%le\n", 0.0000314);
    printf("%.2le\n", 0.0000314);

    return 0 ;
    
}