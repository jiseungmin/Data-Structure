/*
제목 : C언어 기본 자료형 실습 과제
작성자 : 컴퓨터공학부 지승민 
학번 : 2022243094
작성일자 : 3월 8일
*/
#include <stdio.h>

int main(void){
    printf("Sunmoon University\n");
    printf("12345678901234567890\n");
    printf("Computer Science \n");
    printf("My\tFavorite\tFood\n\n");
    printf("Goot\bd\tchance\n");
    printf("Cow\r\a\n");

    return 0;
}